# バッジ素材 12点

SNSの投稿画像・告知・固定ポストなどに使えるSVGバッジです。

- 01_new.svg … 「NEW」
- 02_pr.svg … 「PR」
- 03_muryo.svg … 「無料配布」
- 04_oshirase.svg … 「お知らせ」
- 05_anketo.svg … 「アンケート実施中」
- 06_kotei.svg … 「固定ポスト」
- 07_sale.svg … 「SALE」
- 08_gentei.svg … 「限定」
- 09_hajimemashite.svg … 「はじめまして」
- 10_shigoto.svg … 「お仕事募集中」
- 11_tsuzuki.svg … 「続きはこちら」
- 12_honjitsu.svg … 「本日公開」

ライセンスは同フォルダの ライセンス.txt をご覧ください。
